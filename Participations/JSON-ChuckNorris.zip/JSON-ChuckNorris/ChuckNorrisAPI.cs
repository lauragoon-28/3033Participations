﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JSON_ChuckNorris
{
    public class ChuckNorrisAPI
    {
        public string value { get; set; }

    }
}
